#include <stdio.h>

int saisir();
void remplir(int n, int t[n]);
void inverser(int n, int t[n]);
int saisir2();
void occurence(int x, int n, int t[n]);
void remplacer(int x, int n, int t[n]);
void afficher(int n, int t[n]);

int main() {
    int t[100];
    int n, x;

    n = saisir();
    remplir(n, t);
    afficher(n, t);
    inverser(n, t);
    afficher(n, t);
    x = saisir2();
    occurence(x, n, t);
    x = saisir2();
    remplacer(x, n, t);
    afficher(n, t);

    return 0;
}

int saisir() {
    int n;
    do {
        printf("Donner la taille du tableau (entre 1 et 100) : ");
        scanf("%d", &n);
    } while (n <= 0 || n > 100);
    return n;
}

void remplir(int n, int t[n]) {
    for (int i = 0; i < n; i++) {
        do {
            printf("Donner l'élément %d du tableau : ", i + 1);
            scanf("%d", &t[i]);
        } while (t[i] < 0);
    }
}

void inverser(int n, int t[n]) {
    int aux;
    for (int i = 0; i < n / 2; i++) {
        aux = t[i];
        t[i] = t[n - 1 - i];
        t[n - 1 - i] = aux;
    }
}

int saisir2() {
    int x;
    do {
        printf("Donner un entier positif : ");
        scanf("%d", &x);
    } while (x < 0);
    return x;
}

void occurence(int x, int n, int t[n]) {
    int s = 0;
    for (int i = 0; i < n; i++) {
        if (t[i] == x) {
            s++;
        }
    }
    printf("Le nombre d'occurrences de %d est %d\n", x, s);
}

void remplacer(int x, int n, int t[n]) {
    for (int i = 0; i < n; i++) {
        if (t[i] == x) {
            t[i] = 0;
        }
    }
}

void afficher(int n, int t[n]) {
    printf("Tableau : ");
    for (int i = 0; i < n; i++) {
        printf("%d ", t[i]);
    }
    printf("\n");
}
